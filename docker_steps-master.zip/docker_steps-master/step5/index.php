<?php
echo "I <3 Docker Compose \n\n";